create database contactos;
use contactos;

create table usuarios(
id_usuario int primary key unique ,
nombre_usuario varchar(55)
);
create table usuarios(
    id_usuario int primary key,
    nombre_usuario varchar(55)
);

create table contactos(
    id_contacto int primary key auto_increment,  -- Se agrega un ID único para contactos
    nombre varchar(25),
    apellido varchar(25),
    correo varchar(55),
    num_telefono varchar(15),  -- Se usa varchar para permitir diferentes formatos de números
    url_avatar varchar(55),  -- Corrección del nombre del campo para mayor claridad
    id_usuario int,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
);
